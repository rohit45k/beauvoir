document.getElementById("menu-icon").addEventListener("click", () => {
    document.getElementById("menu-icon").classList.toggle("cross");
    document.getElementById("menu-nav").classList.toggle("open");
})